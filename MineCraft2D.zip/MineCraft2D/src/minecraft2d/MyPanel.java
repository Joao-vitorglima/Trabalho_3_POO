package minecraft2d;

import java.awt.Graphics;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class MyPanel extends JPanel {
    // Classe que estende JPanel para criar painéis personalizados.

    private ImageIcon icon, terra;

    // Declaração de variáveis para armazenar as imagens.

    public MyPanel() {
        // Construtor padrão.

        icon = new ImageIcon("./src/imgs/avatar.png");
        // Carrega a imagem do avatar por padrão.
    }

    public MyPanel(ImageIcon icon) {
        // Construtor que recebe um ImageIcon como parâmetro.

        this.icon = icon;
        // Define o ícone a ser usado.

        // (Este construtor provavelmente não é usado no código que você compartilhou)
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
        repaint();
        // Define o ícone e repinta o painel.
    }

    @Override
    public void paint(Graphics g) {
        // Método de pintura.

        g.drawImage(icon.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
        // Desenha a imagem no painel.
    }
}
