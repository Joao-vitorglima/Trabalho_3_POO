package minecraft2d;



public class MineCraft2D {
    // Classe principal do jogo.

    public static void main(String[] args) {
        
            new Janela();
        
    }
}
