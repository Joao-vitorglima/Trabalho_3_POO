package minecraft2d;

import java.awt.GridLayout;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Janela extends JFrame implements KeyListener {
    // Declaração da classe Janela que herda de JFrame e implementa KeyListener para capturar eventos de teclado.

    private final int size = 800; // Tamanho total da tela
    private final int cols = 40; // Número de colunas
    private final int rows = 20; // Número de linhas

    private final String avatar = "./src/imgs/avatar.png"; // Caminho para a imagem do avatar
    private final String fundo_azul = "./src/imgs/fundo_azul.png"; // Caminho para a imagem de fundo azul
    private final String bloco_flor = "./src/imgs/bloco_flor.png"; // Caminho para a imagem do bloco de flor
    private final String bloco_madeira = "./src/imgs/bloco_madeira.png"; // Caminho para a imagem do bloco de madeira
    private final String bloco_verde = "./src/imgs/bloco_verde.png"; // Caminho para a imagem do bloco verde
    private final String bloco_terra = "./src/imgs/bloco_terra.png"; // Caminho para a imagem do bloco de terra
    private final String pedra_lisa = "./src/imgs/pedra.jpg"; // Caminho para a imagem da pedra lisa
    private final String bed_rock = "./src/imgs/bedrock.png"; // Caminho para a imagem da berock

    // Constantes para tamanhos e caminhos de imagens.
    private MyPanel myPanel[]; // Array de painéis personalizados (blocos)
    private int tipoBloco[]; // Array de tipos de blocos

    // Arrays para armazenar os painéis e tipos de blocos.
    private ImageIcon av; // Imagem do avatar
    private ImageIcon fundo; // Imagem de fundo
    private ImageIcon blc1; // Imagem do bloco 1
    private ImageIcon blc2; // Imagem do bloco 2
    private ImageIcon blc3; // Imagem do bloco 3
    private ImageIcon blc4; // Imagem do bloco 4
    private ImageIcon pedra; // Imagem da pedra
    private ImageIcon bedrock; // Imagem da bedrock

    // Imagens usadas no jogo.
    private int posAv; // Posição do avatar
    private ImageIcon[] savedImages; // Array para salvar imagens

    private int tipoBlocoSelecionado = 0;

    public Janela() {
        // Construtor da classe Janela

        this.setLayout(new GridLayout(rows, cols)); // Define o layout da grade para a janela
        this.setSize(800, 700); // Define o tamanho da janela
        this.setLocationRelativeTo(null); // Centraliza a janela na tela

        // Configurações iniciais da janela.
        av = new ImageIcon(avatar); 
        fundo = new ImageIcon(fundo_azul); 
        blc1 = new ImageIcon(bloco_terra); 
        blc2 = new ImageIcon(bloco_flor); 
        blc3 = new ImageIcon(bloco_madeira); 
        blc4 = new ImageIcon(bloco_verde); 
        pedra = new ImageIcon(pedra_lisa);
        bedrock = new ImageIcon(bed_rock);

        // Carrega as imagens usadas no jogo.
        tipoBloco = new int[size]; // Inicializa o array de tipos de blocos
        myPanel = new MyPanel[size]; // Inicializa o array de painéis

        // Inicializa os arrays para armazenar informações sobre os blocos.
        for (int i = 0; i < size; i++) {
            if (i >= size - 40) {
                myPanel[i] = new MyPanel(bedrock); 
            } else if (i >= size - 80) {
                myPanel[i] = new MyPanel(pedra); 
            } else if (i >= size - 120) {
                myPanel[i] = new MyPanel(blc1);
            } else {
                myPanel[i] = new MyPanel(fundo);
            }
            this.add(myPanel[i]);
        }

        
        posAv = 640; // Define a posição inicial do avatar

        myPanel[640].setIcon(av); // Define a imagem do avatar no painel correspondente

        // Define a imagem inicial do avatar.
        this.addKeyListener(this); // Adiciona um KeyListener à janela

        this.setTitle("Minecraft 2.0"); // Define o título da janela
        this.setExtendedState(2); // Define o estado estendido da janela
        this.setVisible(true); // Torna a janela visível

        // Configurações finais da janela.
        exibeInfo();
    }

    private boolean podeMover(int novaPosicao) {
        // Verifica se o avatar pode mover-se para a nova posição.

        if (novaPosicao < 0 || novaPosicao >= size) {
            return false; // Nova posição fora dos limites
        }
        if (tipoBloco[novaPosicao] != 0) {
            // Verifica se há um bloco na nova posição (diferente de fundo vazio)
            return false; // O avatar não pode mover-se
        }
        return true; // O avatar pode mover-se
    }

    private ImageIcon getIcon(int tipo) {
        // Obtém o ícone correspondente ao tipo de bloco.

        switch (tipoBloco[tipo]) {
            case 1:
                return blc1;
            case 2:
                return blc2;
            case 3:
                return blc3;
            case 4:
                return blc4;
            case 5:
                return pedra;
            default:
                return fundo;
        }
    }

    @Override
    public void keyPressed(KeyEvent key) {

        // movimentações
        if (key.getKeyCode() == KeyEvent.VK_W) {
            int novaPosicao = posAv - cols;
            if (podeMover(novaPosicao)) {
                myPanel[posAv].setIcon(getIcon(posAv));
                posAv = novaPosicao;
                myPanel[posAv].setIcon(av);
            }
        }

        if (key.getKeyCode() == KeyEvent.VK_S) {
            int novaPosicao = posAv + cols;
            if (podeMover(novaPosicao)) {
                myPanel[posAv].setIcon(getIcon(posAv));
                posAv = novaPosicao;
                myPanel[posAv].setIcon(av);
            }
        }

        if (key.getKeyCode() == KeyEvent.VK_A) {
            int novaPosicao = posAv - 1;
            if (podeMover(novaPosicao)) {
                myPanel[posAv].setIcon(getIcon(posAv));
                posAv = novaPosicao;
                myPanel[posAv].setIcon(av);
            }
        }

        if (key.getKeyCode() == KeyEvent.VK_D) {
            int novaPosicao = posAv + 1;
            if (podeMover(novaPosicao)) {
                myPanel[posAv].setIcon(getIcon(posAv));
                posAv = novaPosicao;
                myPanel[posAv].setIcon(av);
            }
        }

        // construções
        if (key.getKeyCode() == KeyEvent.VK_1) {
            JOptionPane.showMessageDialog(null, "Você selecionou o bloco de terra", "BLOCO SELECIONADO", JOptionPane.INFORMATION_MESSAGE);
            tipoBlocoSelecionado = 1;
        }

        if (key.getKeyCode() == KeyEvent.VK_2) {
            JOptionPane.showMessageDialog(null, "Você selecionou o bloco de flor", "BLOCO SELECIONADO", JOptionPane.INFORMATION_MESSAGE);

            tipoBlocoSelecionado = 2;
        }

        if (key.getKeyCode() == KeyEvent.VK_3) {
            JOptionPane.showMessageDialog(null, "Você selecionou o bloco de madeira", "BLOCO SELECIONADO", JOptionPane.INFORMATION_MESSAGE);

            tipoBlocoSelecionado = 3;
        }

        if (key.getKeyCode() == KeyEvent.VK_4) {
            JOptionPane.showMessageDialog(null, "Você selecionou o bloco de folha", "BLOCO SELECIONADO", JOptionPane.INFORMATION_MESSAGE);

            tipoBlocoSelecionado = 4;
        }

        if (key.getKeyCode() == KeyEvent.VK_5) {
            JOptionPane.showMessageDialog(null, "Você selecionou o bloco de pedra", "BLOCO SELECIONADO", JOptionPane.INFORMATION_MESSAGE);

            tipoBlocoSelecionado = 5;
        }

        if (key.getKeyCode() == KeyEvent.VK_SPACE) {
            int novaPosicao = posAv + cols;
            if (novaPosicao < size) {
                myPanel[novaPosicao].setIcon(fundo);
                tipoBloco[novaPosicao] = 0;

                //quando avatar apaga os blocos vai para o lugar do bloco
                myPanel[posAv].setIcon(fundo);
                tipoBloco[posAv] = 0;
                posAv = novaPosicao;
                myPanel[posAv].setIcon(av);
            }
        }
        if (key.getKeyCode() == KeyEvent.VK_E) {
            if (tipoBlocoSelecionado == 1) {
                myPanel[posAv].setIcon(av);
                tipoBloco[posAv] = 1;
                key.setKeyCode(KeyEvent.VK_W);
                keyPressed(key);
            }else if(tipoBlocoSelecionado == 2){
                
                myPanel[posAv].setIcon(av);
                tipoBloco[posAv] = 2;
                key.setKeyCode(KeyEvent.VK_W);
                keyPressed(key);
                
            }else if(tipoBlocoSelecionado == 3){
                
                myPanel[posAv].setIcon(av);
                tipoBloco[posAv] = 3;
                key.setKeyCode(KeyEvent.VK_W);
                keyPressed(key);
                
            }else if(tipoBlocoSelecionado == 4){
                
                myPanel[posAv].setIcon(av);
                tipoBloco[posAv] = 4;
                key.setKeyCode(KeyEvent.VK_W);
                keyPressed(key);
                
            }else if(tipoBlocoSelecionado == 5){
                
                myPanel[posAv].setIcon(av);
                tipoBloco[posAv] = 5;
                key.setKeyCode(KeyEvent.VK_W);
                keyPressed(key);
                
            }
        }

        if (posAv % cols == 0 || (posAv + 1) % cols == 0 || posAv < cols || posAv >= size - cols) {
            for (int i = 0; i < size; i++) {
                if (i >= size - 40) {
                    myPanel[i].setIcon(bedrock);
                } else if (i >= size - 80) {
                    myPanel[i].setIcon(pedra);
                } else if (i >= size - 120) {
                    myPanel[i].setIcon(blc1);
                } else {
                    myPanel[i].setIcon(fundo);
                }
                tipoBloco[i] = 0;
            }
            posAv = 640;
            myPanel[posAv].setIcon(av);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    private void exibeInfo(){
        
        String instrucoes =         "\nMovimentação:\n"+
                            "W -> Movimenta o avatar para cima\n"+
                            "A -> Movimenta o avatar para esquerda\n"+
                            "S -> Movimenta o avatar para baixo\n"+
                            "D -> Movimenta o avatar para direita\n"+
                                        "\nAÇÕES:\n"+
                            "E -> Adiciona o bloco selecionado nas teclas de seleção(de 1 até 5)\n"+
                            "SPACE -> Retira o bloco selecionado nas teclas de seleção(de 1 até 5)\n"+
                                        "\nPLUS:\n"+
                            "Para apagar um bloco é necessário estar acima dele\n"+
                            "Os blocos são colocados por trás do avatar\n"+
                            "Ao tocar nas BORDAS o mundo irá resetar\n"+
                                 "\nBEM VINDO AO MINECRAFT 2.0\n";
                
                JOptionPane.showMessageDialog(null, instrucoes, "INSTRUÇÕES DO JOGO", JOptionPane.INFORMATION_MESSAGE);
                
    }
    
}
